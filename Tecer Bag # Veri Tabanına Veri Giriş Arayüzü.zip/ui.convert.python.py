from PyQt5 import uic
with open("mustisp.py","w",encoding="utf-8") as fout:
    uic.compileUi("mustafaqt5.ui", fout)
    